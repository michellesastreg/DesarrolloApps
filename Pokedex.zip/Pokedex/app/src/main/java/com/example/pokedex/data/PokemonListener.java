package com.example.pokedex.data;

import com.example.pokedex.domain.Pokemon;

public interface PokemonListener {
    void onPokemonClicked(String id);
}
